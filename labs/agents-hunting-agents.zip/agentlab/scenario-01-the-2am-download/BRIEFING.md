# Level 1: The 2 AM Download

**Difficulty:** ★☆☆☆☆☆  
**When:** Monday Nov 16, 2026 - logs cover 06:00-10:00 UTC (midnight to 4 AM in Austin)

## What happened

Monday morning. The file server flagged a **"bulk read"** on the Sales `customers` share overnight, but nobody looked at it. Your manager asks: *did anything leave the building last night?*

## Suspects

| Who | Type | Notes |
|---|---|---|
| Devon Brooks | human | Sales Ops. Laptop lt-devon (10.10.20.21). |
| TidyBot | agent | Tidies the scratch share every 15 minutes (10.10.30.11). |
| ReportBot | agent | Pulls a finance report at 07:00 UTC (10.10.30.14). |
| Nightly backup | scheduled job | files-01 backs up every share at 06:30 UTC. |

*(Not everyone on the list did something wrong - and the culprit might not be a bot.)*

## Your mission

1. **FIND** - Who (or what) went rogue? Was it on purpose or an accident?
2. **PROVE** - Your best clues: file name + line (or timestamp). Try to find the same event in at least two different log types.
3. **TELL** - What happened, step by step, in your own words.

## Where to start

`app/fileserver-audit.jsonl` - look for the bulk-read alert, then follow that account and IP everywhere else.

## Questions to guide you

- [ ] Who read the customer files, and at what local time?
- [ ] What did that computer do right after?
- [ ] Where did the data go, and how much?
- [ ] Did anyone try to hide it?
- [ ] Which big upload is NOT a problem, and why?

## Your files

| Folder | What's in it |
|---|---|
| `dns/` | Company DNS server - every name each machine looked up |
| `zeek/` | Network sensor - `conn.log` (every conversation), `dns.log`, `ssl.log` (which website, by name), `http.log` |
| `netflow/` | Router summaries - who talked to whom, how many bytes |
| `firewall/` | Allowed / denied traffic, with app, category and user |
| `edr/` | Inside each computer: programs started, files touched, connections, alerts |
| `app/` | Application logs - agent gateway (what each AI agent was asked and did), SSO, etc. |
| `artifacts/` | Documents, configs, tickets, inventory - the context |

Stuck? Open `HINTS.md` - three hints, each one gives away a little more. Run `python3 ../tools/timeline.py .` from this folder to see everything in time order.
