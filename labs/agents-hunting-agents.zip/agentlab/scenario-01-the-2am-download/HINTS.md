# Hints - Level 1: The 2 AM Download

Try each one before reading the next.

<details><summary>Hint 1</summary>

Remember all logs are UTC. 08:00Z is 2 AM in Austin. Who is awake?

</details>

<details><summary>Hint 2</summary>

Search every file for `dbrooks` or `10.10.20.21`. In the firewall, compare `bytes_sent` across sessions.

</details>

<details><summary>Hint 3</summary>

Look in edr/ for `7z.exe` and `del`; look in firewall/ for `app=dropbox-upload`. Then read artifacts/hr_notice_devon_brooks.eml.

</details>
