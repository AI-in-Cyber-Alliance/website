# Acceptable Use Policy (excerpt)

4.2  Company data may only be stored in company-approved systems
     (files-01, Salesforce, OneDrive for Business).
4.3  Uploading company data to personal cloud storage (personal Dropbox,
     personal Google Drive, etc.) is prohibited.
4.7  The Sales "customers" share contains confidential customer and pricing data.
