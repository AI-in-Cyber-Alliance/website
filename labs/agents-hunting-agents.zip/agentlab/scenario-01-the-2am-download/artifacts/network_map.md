# Bat City Bikes - network cheat sheet

Bat City Bikes is a (fictional) Austin bike shop chain with an online store and a
small fleet of AI agents that help staff. Every name, IP address, domain and key in
this lab is made up. Do not visit any of the external domains.

## Address plan

| Range            | What lives there                                   |
|------------------|----------------------------------------------------|
| 10.10.0.0/24     | Infrastructure (10.10.0.53 = the company DNS server)|
| 10.10.20.0/24    | Employee laptops and workstations                  |
| 10.10.30.0/24    | AI agents (one VM per agent)                       |
| 10.10.40.0/24    | Servers (databases, file server, SSO, finance API) |
| 10.10.50.0/24    | VPN users (address handed out when someone VPNs in)|
| 198.51.100.10    | Our public address - all outbound traffic is NAT'd to this |
| everything else  | The internet                                       |

## Where each log comes from

| Folder      | Sensor                         | Sees                                                       |
|-------------|--------------------------------|------------------------------------------------------------|
| dns/        | dns-01 (10.10.0.53) query log  | Every name any internal machine asked the company DNS for  |
| zeek/       | Zeek sensor on the core switch | Every conversation inside the network and to the internet |
| netflow/    | edge-rtr-01 + core-sw-01       | Internet traffic, and any traffic to/from the server zone  |
| firewall/   | fw-edge-01 (internet edge) + fw-core-01 (in front of servers) | Allowed/denied sessions, logged when the session ENDS |
| edr/        | EDR agent on each managed machine | Programs started, files touched, network connections   |
| app/        | The applications themselves    | Agent gateway (every agent's LLM + tool calls), SSO, etc.  |

## Things that trip people up

* **All timestamps are UTC.** Austin is UTC-6 in November, so 08:00Z is 2:00 AM local.
* Zeek `ts` is a Unix epoch number. `date -u -d @1763280000` (Linux) or the
  `tools/timeline.py` helper turns it into a normal time.
* NetFlow is one-way: a single conversation shows up as two rows (there and back).
  Long conversations are split into 5-minute rows.
* Firewall rows are written when the session ENDS, so they can look "late".
* Machines without EDR produce no EDR rows at all - silence is also a clue.
