# Scheduled overnight jobs (all times UTC)

| Job                 | Runs on        | When          | What it does                                    |
|---------------------|----------------|---------------|-------------------------------------------------|
| nightly-shares      | files-01       | 06:30 daily   | Backs up all file shares to backups.coldvault.example (~1.8 GB) |
| scratch-cleanup     | TidyBot agent  | every 15 min  | Lists /scratch and removes temp files older than 90 days |
| ar-aging            | ReportBot agent| 07:00 daily   | Pulls the accounts-receivable report from finance-api-01 |
