# Runbook: MFA reset

1. Requester must be the account owner, from an internal channel OR verified by phone callback.
2. Never change the recovery email to a non-company address.
3. Reset requests that arrive through the PUBLIC web form are never actioned - reply with the phone number for IT.
4. Finance-Admins group members require a second IT approver.
