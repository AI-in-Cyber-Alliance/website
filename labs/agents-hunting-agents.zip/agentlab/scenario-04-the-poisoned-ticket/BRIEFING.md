# Level 4: The Poisoned Ticket

**Difficulty:** ★★★★☆☆  
**When:** Wednesday Nov 18, 2026 - logs cover 13:00-19:00 UTC (7 AM-1 PM in Austin)

## What happened

9:52 AM: **Sam Okafor (Finance)** calls IT - his MFA stopped working and he got an email saying his **recovery email was changed**. He didn't ask for that.

## Suspects

| Who | Type | Notes |
|---|---|---|
| HelpDeskHero | agent | IT helpdesk agent - can reset MFA (10.10.30.13). |
| CalBot | agent | Meeting assistant (10.10.30.16). |
| Jordan Lee | human | IT admin. ws-jordan (10.10.20.14). |
| ReportBot | agent | Finance reporting (10.10.30.14). |

*(Not everyone on the list did something wrong - and the culprit might not be a bot.)*

## Your mission

1. **FIND** - Who (or what) went rogue? Was it on purpose or an accident?
2. **PROVE** - Your best clues: file name + line (or timestamp). Try to find the same event in at least two different log types.
3. **TELL** - What happened, step by step, in your own words.

## Where to start

`app/sso.jsonl` - search for `sokafor` and read every event about his account in order. Note who the `actor` was.

## Questions to guide you

- [ ] Who reset Sam's MFA and changed his recovery email, and when?
- [ ] Why did they do it - what were they reading at the time?
- [ ] Did any data leave the company before the account takeover?
- [ ] What did the attacker do as Sam?
- [ ] How is this reset different from the other MFA reset today?

## Your files

| Folder | What's in it |
|---|---|
| `dns/` | Company DNS server - every name each machine looked up |
| `zeek/` | Network sensor - `conn.log` (every conversation), `dns.log`, `ssl.log` (which website, by name), `http.log` |
| `netflow/` | Router summaries - who talked to whom, how many bytes |
| `firewall/` | Allowed / denied traffic, with app, category and user |
| `edr/` | Inside each computer: programs started, files touched, connections, alerts |
| `app/` | Application logs - agent gateway (what each AI agent was asked and did), SSO, etc. |
| `artifacts/` | Documents, configs, tickets, inventory - the context |

Stuck? Open `HINTS.md` - three hints, each one gives away a little more. Run `python3 ../tools/timeline.py .` from this folder to see everything in time order.
