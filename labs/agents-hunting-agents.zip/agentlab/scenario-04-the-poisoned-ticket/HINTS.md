# Hints - Level 4: The Poisoned Ticket

Try each one before reading the next.

<details><summary>Hint 1</summary>

The actor on the reset is a bot's service account. Find that bot's session in agent-gateway.jsonl around the same second.

</details>

<details><summary>Hint 2</summary>

Open artifacts/ticket_HD-5519.json and compare `body_html` with `body_as_shown_to_staff`.

</details>

<details><summary>Hint 3</summary>

Look for `prompt_injection_score` in the gateway log, and for `newly-registered-domain` in the firewall.

</details>
