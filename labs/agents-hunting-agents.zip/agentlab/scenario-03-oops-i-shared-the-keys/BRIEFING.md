# Level 3: Oops, I Shared the Keys

**Difficulty:** ★★★☆☆☆  
**When:** Wednesday Nov 18, 2026 - logs cover 15:00-19:30 UTC (9 AM-1:30 PM in Austin)

## What happened

12:40 PM: The cloud provider emails security: **one of your access keys was found on a public website.** Which bot leaked it, how, and what did the stranger do with it?

## Suspects

| Who | Type | Notes |
|---|---|---|
| BuildBuddy | agent | CI build helper, owns the build cloud key (10.10.30.17). |
| CodePal | agent | Coding assistant (10.10.30.12). |
| Casey Nguyen | human | Customer Support - works with vendors. ws-casey (10.10.20.15). |
| TidyBot | agent | Storage housekeeping (10.10.30.11). |

*(Not everyone on the list did something wrong - and the culprit might not be a bot.)*

## Your mission

1. **FIND** - Who (or what) went rogue? Was it on purpose or an accident?
2. **PROVE** - Your best clues: file name + line (or timestamp). Try to find the same event in at least two different log types.
3. **TELL** - What happened, step by step, in your own words.

## Where to start

`app/cloud-security-alerts.jsonl` gives you the key ID. Search for that key in `app/cloud-audit.jsonl`, then work backwards through the agent gateway and network logs.

## Questions to guide you

- [ ] Which key was exposed and which bot owns it?
- [ ] How did the key end up in public?
- [ ] What IP addresses used the key? Which ones are ours?
- [ ] What did the stranger take or try to do?
- [ ] How long between the leak and the first misuse?

## Your files

| Folder | What's in it |
|---|---|
| `dns/` | Company DNS server - every name each machine looked up |
| `zeek/` | Network sensor - `conn.log` (every conversation), `dns.log`, `ssl.log` (which website, by name), `http.log` |
| `netflow/` | Router summaries - who talked to whom, how many bytes |
| `firewall/` | Allowed / denied traffic, with app, category and user |
| `edr/` | Inside each computer: programs started, files touched, connections, alerts |
| `app/` | Application logs - agent gateway (what each AI agent was asked and did), SSO, etc. |
| `artifacts/` | Documents, configs, tickets, inventory - the context |

Stuck? Open `HINTS.md` - three hints, each one gives away a little more. Run `python3 ../tools/timeline.py .` from this folder to see everything in time order.
