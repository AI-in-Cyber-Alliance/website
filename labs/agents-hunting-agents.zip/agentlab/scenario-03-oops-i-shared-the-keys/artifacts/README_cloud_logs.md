# About app/cloud-audit.jsonl

This is the cloud provider's audit trail (like AWS CloudTrail) for the company's cloud account.
It records every API call made with any of our cloud keys - **from anywhere on the internet**.

Important: if someone outside the company uses one of our keys, it will show up here,
but NOT in our firewall, Zeek, NetFlow or EDR logs, because their traffic never crosses our network.
`sourceIPAddress` tells you where the caller was. 198.51.100.10 is our own office NAT address.
