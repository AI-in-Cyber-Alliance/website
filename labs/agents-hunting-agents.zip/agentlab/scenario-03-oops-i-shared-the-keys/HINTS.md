# Hints - Level 3: Oops, I Shared the Keys

Try each one before reading the next.

<details><summary>Hint 1</summary>

Read artifacts/README_cloud_logs.md first. 198.51.100.10 is our office.

</details>

<details><summary>Hint 2</summary>

In the agent gateway, follow session `bb-8812` from start to finish.

</details>

<details><summary>Hint 3</summary>

Compare BuildBuddy's paste upload with Casey's upload to the vendor - same vendor, very different method.

</details>
