#!/usr/bin/env python3
"""timeline.py - merge every log in a scenario folder into ONE time-ordered list.

No installs needed (Python 3.8+ standard library only).

Examples
    python3 tools/timeline.py scenario-01-the-2am-download
    python3 tools/timeline.py scenario-01-the-2am-download --grep 10.10.20.21
    python3 tools/timeline.py scenario-04-the-poisoned-ticket --grep sokafor --from 15:00 --to 16:00
    python3 tools/timeline.py scenario-06-the-imposter --grep 10.10.30.18 --out imposter.csv

On Windows use `py` instead of `python3`.
Times are shown in UTC and in Austin local time (UTC-6 in November).
"""
import argparse, csv, json, os, sys
from datetime import datetime, timedelta, timezone

UTC = timezone.utc
AUSTIN = timezone(timedelta(hours=-6))


def parse_iso(s):
    return datetime.strptime(s.replace("Z", ""), "%Y-%m-%dT%H:%M:%S.%f").replace(tzinfo=UTC)


def read_zeek(path, kind):
    fields = []
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if line.startswith("#fields"):
                fields = line.split("\t")[1:]
                continue
            if line.startswith("#") or not line:
                continue
            r = dict(zip(fields, line.split("\t")))
            ts = datetime.fromtimestamp(float(r["ts"]), UTC)
            src, dst = r["id.orig_h"], f'{r["id.resp_h"]}:{r["id.resp_p"]}'
            if kind == "conn":
                s = f'{r["proto"]}/{r["service"]} state={r["conn_state"]} sent={r["orig_bytes"]} rcvd={r["resp_bytes"]} dur={r["duration"]}'
            elif kind == "dns":
                s = f'{r["qtype_name"]} {r["query"]} -> {r["answers"]} ({r["rcode_name"]})'
            elif kind == "ssl":
                s = f'TLS to {r["server_name"]} ja3={r["ja3"]}'
            elif kind == "http":
                s = f'{r["method"]} http://{r["host"]}{r["uri"]} -> {r["status_code"]} ua="{r["user_agent"]}"'
            else:
                s = line
            yield ts, f"zeek/{kind}", src, dst, s, line


def read_netflow(path):
    with open(path, encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            yield parse_iso(r["flow_start"]), "netflow", f'{r["src_addr"]}:{r["src_port"]}', f'{r["dst_addr"]}:{r["dst_port"]}', \
                f'proto={r["protocol"]} bytes={r["bytes"]} pkts={r["packets"]} until {r["flow_end"][11:19]}', ",".join(r.values())


def read_firewall(path):
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            ts, dev, _, rest = line.split(" ", 3)
            kv = {}
            for part in rest.split(" "):
                if "=" in part:
                    k, v = part.split("=", 1)
                    kv[k] = v.strip('"')
            s = f'{dev} {kv.get("action")} rule={kv.get("rule")} app={kv.get("app")} cat={kv.get("category")} sent={kv.get("bytes_sent")} sni={kv.get("sni", "-")} user={kv.get("user")}'
            yield parse_iso(ts), "firewall", kv.get("src", "-"), f'{kv.get("dst")}:{kv.get("dport")}', s, line


def read_resolver(path):
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            ts = datetime.strptime(line[:24], "%d-%b-%Y %H:%M:%S.%f").replace(tzinfo=UTC)
            client = line.split(" client ")[1].split(" ")[1].split("#")[0]
            q = line.split("query: ")[1].split(" +")[0]
            yield ts, "dns/resolver", client, "10.10.0.53", "query " + q, line


def read_jsonl(path, label):
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            ts = parse_iso(r.get("timestamp") or r.get("ts"))
            if label == "edr":
                src = f'{r.get("host")}({r.get("host_ip")})'
                p = r.get("process", {})
                extra = ""
                for k in ("file", "network", "dns", "alert", "container"):
                    if k in r:
                        extra = " " + json.dumps(r[k])
                s = f'{r["event_type"]} user={r.get("user")} {p.get("cmdline", "")}{extra}'
                dst = r.get("network", {}).get("dst_ip", "-") if "network" in r else "-"
            else:
                src = str(r.get("agent_ip") or r.get("src_ip") or r.get("client_ip") or r.get("sourceIPAddress") or (r.get("sourceIPs") or ["-"])[0])
                dst = "-"
                s = json.dumps({k: v for k, v in r.items() if k != "timestamp"})
            yield ts, label, src, dst, s, line


def read_pgaudit(path):
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            ts = datetime.strptime(line[:23], "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=UTC)
            parts = line.split(" ")
            yield ts, "app/" + os.path.basename(path), parts[5], "db-prod-01", line.split("AUDIT: ")[1], line


def collect(folder):
    for root, _, files in os.walk(folder):
        if os.sep + "artifacts" in root:
            continue
        for f in sorted(files):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, folder).replace(os.sep, "/")
            try:
                if rel.startswith("zeek/"):
                    yield from read_zeek(p, f.split(".")[0])
                elif rel.startswith("netflow/"):
                    yield from read_netflow(p)
                elif rel.startswith("firewall/"):
                    yield from read_firewall(p)
                elif rel.startswith("dns/"):
                    yield from read_resolver(p)
                elif rel.startswith("edr/"):
                    yield from read_jsonl(p, "edr")
                elif f.endswith(".jsonl"):
                    yield from read_jsonl(p, "app/" + f.replace(".jsonl", ""))
                elif f.endswith("pgaudit.log"):
                    yield from read_pgaudit(p)
            except Exception as e:  # keep going if one file is odd
                print(f"warning: could not read {rel}: {e}", file=sys.stderr)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("folder", help="scenario folder, e.g. scenario-01-the-2am-download")
    ap.add_argument("--grep", action="append", help="only keep rows containing this text (case-insensitive). Repeat to require several.")
    ap.add_argument("--source", help="only keep sources starting with this, e.g. edr, zeek/dns, app/sso, firewall")
    ap.add_argument("--from", dest="t_from", help="UTC start time HH:MM")
    ap.add_argument("--to", dest="t_to", help="UTC end time HH:MM")
    ap.add_argument("--out", help="write a CSV you can open in Excel / Google Sheets")
    ap.add_argument("--limit", type=int, default=400, help="max rows to print on screen (default 400)")
    a = ap.parse_args()

    rows = sorted(collect(a.folder), key=lambda x: x[0])
    def keep(r):
        ts, src_kind, src, dst, summ, raw = r
        hm = ts.strftime("%H:%M")
        if a.t_from and hm < a.t_from: return False
        if a.t_to and hm > a.t_to: return False
        if a.source and not src_kind.startswith(a.source): return False
        if a.grep and not all(g.lower() in raw.lower() or g.lower() in summ.lower() for g in a.grep): return False
        return True
    rows = [r for r in rows if keep(r)]
    if a.out:
        with open(a.out, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["time_utc", "time_austin", "source", "from", "to", "summary"])
            for ts, k, s, d, summ, _ in rows:
                w.writerow([ts.strftime("%Y-%m-%d %H:%M:%S"), ts.astimezone(AUSTIN).strftime("%a %I:%M:%S %p"), k, s, d, summ])
        print(f"wrote {len(rows)} rows to {a.out}")
    for ts, k, s, d, summ, _ in rows[: a.limit]:
        print(f'{ts.strftime("%H:%M:%S")}Z ({ts.astimezone(AUSTIN).strftime("%I:%M %p")})  {k:<22} {s:<24} -> {d:<22} {summ[:180]}')
    if len(rows) > a.limit:
        print(f"... {len(rows) - a.limit} more rows (narrow with --grep/--from/--to or use --out)")


if __name__ == "__main__":
    main()
