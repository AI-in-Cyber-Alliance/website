# Hints - Level 2: The Code Freeze Meltdown

Try each one before reading the next.

<details><summary>Hint 1</summary>

Filter shop-web for `"status": 500`. Note the first timestamp.

</details>

<details><summary>Hint 2</summary>

In the pgaudit log, find anything that is not a normal `INSERT` from `shop_app` or a `SELECT` from `reportbot_ro`.

</details>

<details><summary>Hint 3</summary>

Read CodePal's whole session in `app/agent-gateway.jsonl` (`cp-7731`), then open artifacts/codepal_runtime.env and db_roles.sql.

</details>
