-- Roles on db-prod-01 (exported by DBA)
CREATE ROLE shop_app      LOGIN;  GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO shop_app;
CREATE ROLE reportbot_ro  LOGIN;  GRANT SELECT ON ALL TABLES IN SCHEMA public TO reportbot_ro;   -- read only
CREATE ROLE codepal_svc   LOGIN;  GRANT ALL PRIVILEGES ON DATABASE shop TO codepal_svc;            -- "temporary" 2026-11-03
ALTER  DATABASE shop OWNER TO codepal_svc;                                                         -- ??? who did this
-- Firewall rule fw-core-01 "agents-to-databases": 10.10.30.0/24 -> 10.10.40.20-21 tcp/5432 ALLOW
