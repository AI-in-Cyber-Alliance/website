# Level 2: The Code Freeze Meltdown

**Difficulty:** ★★☆☆☆☆  
**When:** Tuesday Nov 17, 2026 - logs cover 14:00-18:00 UTC (8 AM-noon in Austin)

## What happened

9:20 AM: Customer Support opens a **P1** - customers can't log in ("user not found"). Engineering swears it's a **code freeze** and nobody deployed anything.

## Suspects

| Who | Type | Notes |
|---|---|---|
| CodePal | agent | Coding assistant, working on a failing test (10.10.30.12). |
| ReportBot | agent | Reads sales numbers from the prod DB daily (10.10.30.14). |
| TidyBot | agent | Storage housekeeping (10.10.30.11). |
| Priya Shah | human | Engineer. Laptop ws-priya (10.10.20.12). |

*(Not everyone on the list did something wrong - and the culprit might not be a bot.)*

## Your mission

1. **FIND** - Who (or what) went rogue? Was it on purpose or an accident?
2. **PROVE** - Your best clues: file name + line (or timestamp). Try to find the same event in at least two different log types.
3. **TELL** - What happened, step by step, in your own words.

## Where to start

`app/shop-web.jsonl` - find the exact minute errors started, then look at `app/db-prod-01_pgaudit.log` around that minute.

## Questions to guide you

- [ ] When exactly did customer errors start?
- [ ] What happened to the production database at that moment, and who did it?
- [ ] Was that bot supposed to be talking to production?
- [ ] Is the data in the users table now real?
- [ ] Did the bot tell the truth about what it did?

## Your files

| Folder | What's in it |
|---|---|
| `dns/` | Company DNS server - every name each machine looked up |
| `zeek/` | Network sensor - `conn.log` (every conversation), `dns.log`, `ssl.log` (which website, by name), `http.log` |
| `netflow/` | Router summaries - who talked to whom, how many bytes |
| `firewall/` | Allowed / denied traffic, with app, category and user |
| `edr/` | Inside each computer: programs started, files touched, connections, alerts |
| `app/` | Application logs - agent gateway (what each AI agent was asked and did), SSO, etc. |
| `artifacts/` | Documents, configs, tickets, inventory - the context |

Stuck? Open `HINTS.md` - three hints, each one gives away a little more. Run `python3 ../tools/timeline.py .` from this folder to see everything in time order.
