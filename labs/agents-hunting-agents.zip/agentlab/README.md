# Agents Hunting Agents - hands-on hunt lab

AI Cyber Alliance Austin · Wed Nov 18, 2026 · ACC Rio Grande, CGCS lab

You are the security team at **Bat City Bikes**, a (made-up) Austin bike shop chain that lets a
small crew of AI agents help its staff. Something has gone rogue. Sometimes it's a person, sometimes
it's a bot that made a mistake, and sometimes it's a bot that was tricked or hijacked.
Your job is to work out which, using the same kinds of logs real security teams use.

**No experience needed.** If you can search a text file, you can do this.

## The six cases

| Folder | Level | Who goes rogue | Rough time |
|---|---|---|---|
| `scenario-01-the-2am-download` | ★☆☆☆☆☆ | A human, on purpose | 10 min |
| `scenario-02-code-freeze-meltdown` | ★★☆☆☆☆ | An agent, by accident (a replay of a real 2025 incident) | 10-15 min |
| `scenario-03-oops-i-shared-the-keys` | ★★★☆☆☆ | An agent by accident, then a stranger | 15 min |
| `scenario-04-the-poisoned-ticket` | ★★★★☆☆ | An agent, hijacked on purpose | 15-20 min |
| `scenario-05-the-tool-that-lied` | ★★★★★☆ | An agent, steered by a poisoned tool | 20 min |
| `scenario-06-the-imposter` | ★★★★★★ | A human disguised as an agent | 25+ min |

New to this? Start at 01 and level up. Already hunt for a living? Jump to 05 or 06.

## How to play

1. Open a scenario folder and read **`BRIEFING.md`** - the alert, the suspects, and where to start.
2. Dig through the logs. Use whatever you like: a text editor, `grep`, a spreadsheet, `jq`, Splunk, an AI assistant, VigilSOC...
3. Stuck? **`HINTS.md`** has three hints that get more specific.
4. Send your answer (the facilitator will show a QR code):
   - **FIND** - who or what went rogue, and was it on purpose or an accident?
   - **PROVE** - your best clues: file + line number (or timestamp). Bonus if two different log types show the same thing.
   - **TELL** - what happened, step by step, in your own words.

## Fastest way in: the timeline tool

Every scenario has 5-9 different log files. `tools/timeline.py` merges them into one list in time order,
with Austin local time next to UTC. Needs only Python 3 (no installs).

```bash
cd agents-hunting-agents-lab
python3 tools/timeline.py scenario-01-the-2am-download                       # everything
python3 tools/timeline.py scenario-01-the-2am-download --grep 10.10.20.21    # one machine
python3 tools/timeline.py scenario-04-the-poisoned-ticket --grep sokafor --from 15:00 --to 16:00
python3 tools/timeline.py scenario-06-the-imposter --out s6.csv              # open in Excel / Sheets
```

Windows: use `py` instead of `python3`.

See **`CHEATSHEET.md`** for what each log type is, the fields that matter, and copy-paste search commands
for Mac/Linux and Windows PowerShell.

## Ground rules

* Everything here is fictional: the company, people, IP addresses, domains, keys and passwords.
  External domains are made up - **do not visit them**.
* All timestamps are **UTC**. Austin is UTC-6 in November.
* Each scenario folder is self-contained and has its own `artifacts/` (inventory, network map, tickets, configs).
