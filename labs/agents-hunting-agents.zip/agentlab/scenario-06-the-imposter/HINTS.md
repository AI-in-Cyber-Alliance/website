# Hints - Level 6: The Imposter

Try each one before reading the next.

<details><summary>Hint 1</summary>

Two machines call themselves ReportBot. Compare them on: IP, EDR presence, TLS ja3, endpoints requested, bucket name, LLM usage.

</details>

<details><summary>Hint 2</summary>

app/k8s-audit.jsonl + artifacts/kubectl_get_pods_agents_2000Z.txt tell you where 10.10.30.18 came from. Then check app/vpn.jsonl and artifacts/pto_calendar.csv.

</details>

<details><summary>Hint 3</summary>

Search app/sso.jsonl for `pshah` before 05:00 UTC. And read app/scoutbot-findings.jsonl.

</details>
