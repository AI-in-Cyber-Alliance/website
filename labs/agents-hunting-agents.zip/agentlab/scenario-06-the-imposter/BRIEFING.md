# Level 6: The Imposter

**Difficulty:** ★★★★★★  
**When:** Wednesday Nov 18, 2026 - logs cover 04:00-20:00 UTC (10 PM Tue - 2 PM Wed in Austin)

## What happened

**Threat hunt - no alert fired.** Yesterday, uploads to online storage from the agent subnet were about 70x a normal day. Every agent dashboard looks green. Find out which agent - if any - is not what it seems.

## Suspects

| Who | Type | Notes |
|---|---|---|
| ReportBot | agent | Finance reporting, daily 13:00 UTC. |
| ScoutBot | agent | Security scanner - very loud today (10.10.30.15). |
| CodePal | agent | Coding assistant (10.10.30.12). |
| BuildBuddy | agent | CI helper (10.10.30.17). |
| Priya Shah | human | Engineer with Kubernetes admin access. |

*(Not everyone on the list did something wrong - and the culprit might not be a bot.)*

## Your mission

1. **FIND** - Who (or what) went rogue? Was it on purpose or an accident?
2. **PROVE** - Your best clues: file name + line (or timestamp). Try to find the same event in at least two different log types.
3. **TELL** - What happened, step by step, in your own words.

## Where to start

`firewall/firewall.log` - add up `bytes_sent` to `category=online-storage-and-backup` per source IP. Then check every source IP against `artifacts/asset_inventory.csv`.

## Questions to guide you

- [ ] Which IP sent the most data to online storage? Is it in the inventory?
- [ ] Who or what is that IP, and when did it appear?
- [ ] How did it get ReportBot's identity?
- [ ] What did it take that the real ReportBot never takes?
- [ ] Which of today's loud events are a distraction?
- [ ] Did any of our own agents notice?

## Your files

| Folder | What's in it |
|---|---|
| `dns/` | Company DNS server - every name each machine looked up |
| `zeek/` | Network sensor - `conn.log` (every conversation), `dns.log`, `ssl.log` (which website, by name), `http.log` |
| `netflow/` | Router summaries - who talked to whom, how many bytes |
| `firewall/` | Allowed / denied traffic, with app, category and user |
| `edr/` | Inside each computer: programs started, files touched, connections, alerts |
| `app/` | Application logs - agent gateway (what each AI agent was asked and did), SSO, etc. |
| `artifacts/` | Documents, configs, tickets, inventory - the context |

Stuck? Open `HINTS.md` - three hints, each one gives away a little more. Run `python3 ../tools/timeline.py .` from this folder to see everything in time order.
