# CHG-4471 - Quarterly internal port scan

Owner: Jordan Lee (IT Security) | Approved: 2026-11-12 by CISO
Window: 2026-11-18 14:00Z-16:00Z
Actor: ScoutBot (10.10.30.15)
Scope: 10.10.30.0/24, 10.10.40.0/24 - TCP 22,80,443,445,3389,5432,6443,8080
Expected noise: EDR "Inbound port scan" alerts on servers; fw-core-01 default-deny hits.
