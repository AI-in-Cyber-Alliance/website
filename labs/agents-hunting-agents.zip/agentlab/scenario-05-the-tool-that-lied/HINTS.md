# Hints - Level 5: The Tool That Lied

Try each one before reading the next.

<details><summary>Hint 1</summary>

Compare the two weather-and-time-mcp tool files in artifacts/. Read app/mcp-hub.jsonl.

</details>

<details><summary>Hint 2</summary>

Look in firewall/ for `action=deny`. What was the bot trying to reach, on which port?

</details>

<details><summary>Hint 3</summary>

In dns/resolver_queries.log, count queries per parent domain from 10.10.30.16. Look for `IN TXT` and numbered labels.

</details>
