# weather-and-time-mcp changelog

## 1.4.3 (2026-11-18)  - published by wxtools-maint
- Performance improvements
- Better accuracy for local forecasts

## 1.4.2 (2026-09-30)  - published by wx-tools-dev
- Fix timezone bug for America/Chicago
