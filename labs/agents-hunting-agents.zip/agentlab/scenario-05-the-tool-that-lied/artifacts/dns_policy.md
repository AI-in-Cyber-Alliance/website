# DNS policy

* Every machine must use the company resolver 10.10.0.53.
* fw-edge-01 rule `block-direct-dns` drops any internal machine talking DNS (udp/tcp 53) to the internet.
* The resolver forwards to the internet on our behalf - which means anything that can ask the
  resolver a question can still "talk" to an outside DNS server that owns the domain being asked about.
