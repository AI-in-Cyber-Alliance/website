# Level 5: The Tool That Lied

**Difficulty:** ★★★★★☆  
**When:** Wednesday Nov 18, 2026 - logs cover 16:00-20:00 UTC (10 AM-2 PM in Austin)

## What happened

EDR raised a medium alert: **"Credential file read by non-interactive agent process"** on `agent-calbot`. CalBot's owner says *"it just books meetings."* False positive?

## Suspects

| Who | Type | Notes |
|---|---|---|
| CalBot | agent | Meeting assistant - and the MCP tools it uses (10.10.30.16). |
| ScoutBot | agent | Security scanner, approved sweep 17:00-18:00 UTC (10.10.30.15). |
| CodePal | agent | Coding assistant (10.10.30.12). |
| HelpDeskHero | agent | IT helpdesk agent (10.10.30.13). |

*(Not everyone on the list did something wrong - and the culprit might not be a bot.)*

## Your mission

1. **FIND** - Who (or what) went rogue? Was it on purpose or an accident?
2. **PROVE** - Your best clues: file name + line (or timestamp). Try to find the same event in at least two different log types.
3. **TELL** - What happened, step by step, in your own words.

## Where to start

`edr/edr.jsonl` - find the alert, then read CalBot's session in `app/agent-gateway.jsonl` around the same time. Why would a calendar bot read key files?

## Questions to guide you

- [ ] What told CalBot to read the secret files?
- [ ] What changed shortly before - and was a human asked?
- [ ] Where did the secrets go? (Hint: the firewall stopped the easy way.)
- [ ] How do you tell the leak apart from normal random-looking DNS?
- [ ] Stretch: what exactly was stolen?

## Your files

| Folder | What's in it |
|---|---|
| `dns/` | Company DNS server - every name each machine looked up |
| `zeek/` | Network sensor - `conn.log` (every conversation), `dns.log`, `ssl.log` (which website, by name), `http.log` |
| `netflow/` | Router summaries - who talked to whom, how many bytes |
| `firewall/` | Allowed / denied traffic, with app, category and user |
| `edr/` | Inside each computer: programs started, files touched, connections, alerts |
| `app/` | Application logs - agent gateway (what each AI agent was asked and did), SSO, etc. |
| `artifacts/` | Documents, configs, tickets, inventory - the context |

Stuck? Open `HINTS.md` - three hints, each one gives away a little more. Run `python3 ../tools/timeline.py .` from this folder to see everything in time order.
